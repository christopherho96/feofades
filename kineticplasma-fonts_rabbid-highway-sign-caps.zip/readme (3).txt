﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by Robert Jablonski*.
This font has a homepage where this archive and other versions may be found:
http://fontstruct.com/fontstructions/show/998167

*NOTE: “Rabbid Highway Sign Bold Caps” was originally cloned (copied) from
the FontStruction “Rabbid Highway Sign Caps”
(http://fontstruct.com/fontstructions/show/982615) by Robert Jablonski, which is
licensed under a Creative Commons CC0 Public Domain Dedication license
(http://creativecommons.org/publicdomain/zero/1.0/).

Try Fontstruct at http://fontstruct.com
It’s easy and it’s fun.

NOTE FOR FLASH USERS: Fontstruct fonts (fontstructions) are optimized for Flash.
If the font in this archive is a pixel font, it is best displayed at a font-size
of 16.

Fontstruct is sponsored by FontShop.
Visit them at http://fontshop.com
FontShop is the original independent font retailer. We’ve been around since
the dawn of digital type. Whether you need the right font or need to create the
right font from scratch, let our 23 years of experience work for you.

Fontstruct is copyright ©2014 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
